/************************************************************************************************************

Student Name:  Blake Fowler
Course:  C++ Programming (COP2334)
Date:  4/26/2024

This is the Final Project
************************************************************************************************************/

#include <iostream>
#include <fstream>
#include <sstream>
#include "Book.h"

using namespace std;

//Setting up Book to base everything else off of
Book::Book() {
    
}


//Setting up the details of the book with required parameters
Book::Book(string title, string author, int year, string genre, string available) {
    //Variable creation with "this" statement
    this->title = title;
    this->author = author;
    this->year = year;
    this->genre = genre;
    this->available = available;
}

//All of our getter methods

string Book::getTitle() {
    return title;
}

string Book::getAuthor()  {
    return author;
}

int Book::getYear()  {
    return year;
}

string Book::getGenre()  {
    return genre;
}

string Book::getAvailabilityStatus()  { 
    return available;
}


//All of our setter methods


void Book::setTitle(string title) {
    this->title = title;
}

void Book::setAuthor(string author) {
    this->author = author;
}

void Book::setYear(int year) {
    this->year = year;
}

void Book::setGenre(string genre) {
    this->genre = genre;
}

void Book::setAvailabilityStatus(string available) { 
    this->available = available;
}



//Printing out the details of each book with specified attributes
void Book::printBookDetails() const {    
    cout << "Title: " << title << endl;
    cout << "Author: " << author << endl;
    cout << "Year: " << year << endl;
    cout << "Genre: " << genre << endl;
    cout << "Available: " << available << endl;
}





























