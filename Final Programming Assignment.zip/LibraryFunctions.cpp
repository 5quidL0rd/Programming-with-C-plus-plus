/************************************************************************************************************

Student Name:  Blake Fowler
Course:  C++ Programming (COP2334)
Date:  4/26/2024

This is the Final Project
************************************************************************************************************/



#include "LibraryFunctions.h"
#include "Book.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <vector>

using namespace std;

//Setting up our filename and maximum book count 
string filename = "books.txt";
int const MAX_BOOKS = 100;

void readBooksFile(Book bookList[], int& bookCount) {
    ifstream file("books.txt");
    string line;
    bookCount = 0;

    if (file.is_open()) {
        while (getline(file, line)) {
            istringstream iss(line);
            string title, author, genre, available;
            int year;

            if (getline(iss, title, ',') &&
                getline(iss, author, ',') &&
                (iss >> year, iss.ignore()) &&
                getline(iss, genre, ',') &&
                getline(iss, available)) {

                
                bookList[bookCount].setTitle(title);
                bookList[bookCount].setAuthor(author);
                bookList[bookCount].setYear(year);
                bookList[bookCount].setGenre(genre);
                bookList[bookCount].setAvailabilityStatus(available);

                bookCount++;
            } /*else {
              //  cout << "Error parsing line: " << line << std::endl;
            }*/
        }
        file.close();
    } else {
        cout << "Unable to open file books.txt" << std::endl;
    }
}


void listAllBooks(Book bookList[], int& bookCount) {
    for (int i = 0; i < bookCount; ++i) {
        cout << "Book " << i + 1 << ":" << endl;
        bookList[i].printBookDetails();
        cout << endl;
    }
}

void addBook(Book bookList[], int& bookCount) {
    if (bookCount >= MAX_BOOKS) { 
        cout << "Cannot add more books. Maximum limit reached." << endl;
        return;
    }

    string title, author, genre, available; 
    int year;
    cout << "Enter the title of the book: ";
    cin.ignore();
    getline(cin, title);
    cout << "Enter the author of the book: ";
    getline(cin, author);
    cout << "Enter the publication year of the book: ";
    cin >> year;
    cin.ignore();
    cout << "Enter the genre of the book: ";
    getline(cin, genre);
    cout << "Enter the availability status of the book (available/borrowed): ";
    getline(cin, available);
    if (available == "available") {
        available = "1";
    }
    else {
        available = "0";
    }
    

    //Setting everything 
    bookList[bookCount].setTitle(title);
    bookList[bookCount].setAuthor(author);
    bookList[bookCount].setYear(year);
    bookList[bookCount].setGenre(genre);
    bookList[bookCount].setAvailabilityStatus(available);
    
    
     // Open the file in append mode
     ofstream file("books.txt");
    if (file.is_open()) {
        // Write all the books in the list to the file
        for (int i = 0; i < bookCount; i++) {
            file << bookList[i].getTitle() << "," << bookList[i].getAuthor() << "," << bookList[i].getYear() << "," << bookList[i].getGenre() 
            << "," << bookList[i].getAvailabilityStatus() << endl;
        }
        // Write the new book information to the file
        file << title << "," << author << "," << year << "," << genre << "," << available << endl;
        file.close();
        cout << "Book added successfully!" << endl;
    } else {
        cout << "Unable to open file." << endl;
    }
   bookCount++; //Increment book count since we added a new book with this option
}





void lookUpBook(Book bookList[], int bookCount) {
    string searchCriteria; //string for purposes of ease of search
    cout << "Enter search criteria (title, author, year, genre): ";
    cin.ignore();
    getline(cin, searchCriteria);
   // cin.ignore();
   /* cin >> searchCriteria;
      cin.ignore();*/
   

    // Search for books based on the search criteria
    for (int i = 0; i < bookCount; ++i) {
        Book book = bookList[i];
        if (searchCriteria == book.getTitle() || searchCriteria == book.getAuthor() ||
            searchCriteria == to_string(book.getYear()) || searchCriteria == book.getGenre()) {
            cout << "Matching Book:" << endl;
            book.printBookDetails();
            cout << endl;
        }
    }
}

//Book report
void generateReport(Book bookList[], int bookCount) {
    ofstream reportFile("library_report.txt"); //Opening up a new separate file
    if (reportFile.is_open()) {
        //While file is open we iterate through the file accordingly 
        for (int i = 0; i < bookCount; ++i) {
            reportFile << "Book " << i + 1 << ":" << endl;
            reportFile << "Title: " << bookList[i].getTitle() << endl;
            reportFile << "Author: " << bookList[i].getAuthor() << endl;
            reportFile << "Year: " << bookList[i].getYear() << endl;
            reportFile << "Genre: " << bookList[i].getGenre() << endl;
            reportFile << "Availability: " << bookList[i].getAvailabilityStatus() << endl;
            reportFile << endl;
        }
        reportFile.close();
        cout << "Report generated successfully to library_report.txt" << endl;
    } else {
        cout << "Error opening file: library_report.txt" << endl;
    }
}


void borrowBook(Book bookList[], int bookCount) {
    string title;
    cout << "Enter the title of the book to borrow: ";
    cin.ignore();
    getline(cin, title);

    for (int i = 0; i < bookCount; ++i) {
        //If the titles match up we say it's been found and borrowed
        if (title == bookList[i].getTitle()) {
            bookList[i].setAvailabilityStatus("false");
            cout << "Book '" << title << "' has been borrowed successfully." << endl;
            return;
        }
    }
    cout << "Book not found in the library." << endl;
}


void returnBook(Book bookList[], int bookCount) {
    string title;
    cout << "Enter the title of the book to return: ";
    cin.ignore();
    getline(cin, title);

    for (int i = 0; i < bookCount; ++i) {
        if (title == bookList[i].getTitle()) {
            bookList[i].setAvailabilityStatus("true");
            cout << "Book '" << title << "' has been returned successfully." << endl;
            return;
        }
    }
    cout << "Book not found in the library." << endl;
}


void updateBookFile(const Book bookList[], int bookCount) {
    ofstream file("library_report.txt"); // open the file for writing

    // Check if the file is open
    if (!file.is_open()) {
        cout << "Error opening file!" << std::endl;
        return;
    }

    // Write book information to the file
    for (int i = 0; i < bookCount; i++) {
        Book copy = bookList[i]; // Make a copy of the Book object
        copy.setAvailabilityStatus("true"); // Modify the copy
        file << copy.getTitle() << ","
             << copy.getAuthor() << ","
             << copy.getYear() << ","
             << copy.getGenre() << ","
             << copy.getAvailabilityStatus() << endl; // Write the modified copy to the file
    }

    // Close the file
    file.close();
}


