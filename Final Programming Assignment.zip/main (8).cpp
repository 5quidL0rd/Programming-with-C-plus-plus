
/************************************************************************************************************

Student Name:  Blake Fowler
Course:  C++ Programming (COP2334)
Date:  4/26/2024

In this program we create a library filled with books from the books.txt file.
Additionally, the user is able to list all the books, look up books, borrow books
and add books until there are 100 books in the library. The user can then
generate a report and do any combination of the aforementiond actions until they
wish to exit the program. 
************************************************************************************************************/

//Setting everything up 
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <sstream>
using namespace std;


#include <vector>
#include "Book.h"
#include "LibraryFunctions.h"


int main() {

    const int MAX_BOOKS = 100;
    Book bookList[MAX_BOOKS];  
    int bookCount = 0;
    bool exitMenu = false;


 //While user does not want to exit by typing 8. we continuously loop 
    while (!exitMenu) {
        cout << "\nLibrary Management System " << endl;
        cout << "1. List all books " << endl;
        cout << "2. Add a book " << endl;
        cout << "3. Look up a book " << endl;
        cout << "4. Borrow a book " << endl;
        cout << "5. Return a book " << endl;
        cout << "6. Generate library report " << endl;
        cout << "7. Exit " << endl;
        cout << "Please enter a number: ";

        int choice;
        cin >> choice;
        cin.ignore(); // Clear the newline character from the buffer
        
        readBooksFile(bookList, bookCount);


        //Switch statement present user his choice and executes functions accordingly 
        switch (choice) {
            case 1:
                listAllBooks(bookList, bookCount);
                break;
            case 2:
                addBook(bookList, bookCount);
                break;
            case 3:
                lookUpBook(bookList, bookCount);
                break;
            case 4:
                borrowBook(bookList, bookCount);
                break;
            case 5:
                returnBook(bookList, bookCount);
                break;
            case 6:
                generateReport(bookList, bookCount);
                break;
            case 7:
                exitMenu = true;
                cout << "Thank you for reading!" << endl << "Come back soon!" << endl;
                break;
            default:
                cout << "Invalid choice. Please try again.\n"; //Safeguards us from dangerous inputs
        }
    }

    return 0;
}


























