/************************************************************************************************************

Student Name:  Blake Fowler
Course:  C++ Programming (COP2334)
Date:  4/26/2024

This is the Final Project
************************************************************************************************************/



//Setting up the header file
#ifndef BOOK_H
#define BOOK_H

#include <string>

using namespace std;


class Book {
   
    private:
    //All of our private variables
    string title;
    string author;
    int year;
    string genre;
    string available; 
    
    
    
    
    public:
    
    
    const int MAX_BOOKS = 100;
    
    
    //All our public mutators and setters
    Book();
    Book(string title, string author, int year, string genre, string available); 

    string getTitle();
    string getAuthor();
    int getYear();
    string getGenre();
    string getAvailabilityStatus(); 
    
   // void readBooksFile(const string& filename, Book bookList[], int& bookCount);
    void setTitle(string title);
    void setAuthor(string author);
    void setYear(int year);
    void setGenre(string genre);
    void setAvailabilityStatus(string available); 
    
    
    void printBookDetails() const; //printing out the details

};

#endif //Ending the header part 









