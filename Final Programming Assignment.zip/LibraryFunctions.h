/************************************************************************************************************

Student Name:  Blake Fowler
Course:  C++ Programming (COP2334)
Date:  4/26/2024

This is the Final Project
************************************************************************************************************/



#ifndef LIBRARY_FUNCTIONS_H
#define LIBRARY_FUNCTIONS_H

#include <string>
#include <vector>

#include "Book.h"  

using namespace std;

// Forward declare Book class
class Book;

void readBooksFile(Book bookList[], int& bookCount);

void listAllBooks(Book bookList[], int& bookCount);

void addBook(Book bookList[], int& bookCount);

void lookUpBook(Book bookList[], int bookCount);

void generateReport(Book bookList[], int bookCount);

void borrowBook(Book bookList[], int bookCount);

void returnBook(Book bookList[], int bookCount);

void updateBookFile(const Book booklist[], int bookCount);




#endif // LIBRARY_FUNCTIONS_H






