/************************************************************************************************************

Student Name:  Blake Fowler
Course:  C++ Programming (COP2334)
Date:  4/12/2024

This is Programming Project 5. In this class all the constructors are created
to be used in main. We include Restaurant.h to obtain all the variable names. 
************************************************************************************************************/


#include "Restaurant.h" //Include our header file
#include <iostream>
using namespace std;


//Instantiation of our restaurant class
Restaurant::Restaurant() {
    name = "Default Restaurant";
    seatingCapacity = 0;
    ratingSum = 0;
    numOfRatings = 0;
    maxRating = 0;
}

//Our default restaurant
Restaurant::Restaurant(string name, int seatingCapacity) {
    this->name = name;
    this->seatingCapacity = seatingCapacity;
    ratingSum = 0;
    numOfRatings = 0;
    maxRating = 0;
}


//Our getter methods
string Restaurant::getName() {
    return name;
}

int Restaurant::getSeatingCapacity() {
    return seatingCapacity;
}

int Restaurant::getMaxRating() {
    return maxRating;
}


//Now for our setter methods
void Restaurant::setName(string restaurantName) {
    name = restaurantName;
}


void Restaurant::setSeatingCapacity(int restaurantSeatingCapacity) {
    seatingCapacity = restaurantSeatingCapacity;
}

//Determines the rating
void Restaurant::addRating(int newRating) {
    if (newRating >= 1 && newRating <= 5) {
        ratingSum += newRating;
        numOfRatings++; // Increment the number of ratings
    } else {
        cout << "Error. Rating must be between 1 and 5." << endl;
    }
}


//Another getter for ratings
double Restaurant::getAverage() {

    if (numOfRatings == 0) {
        return -1; 
    }
    //Calculates the average rating making sure to avoid lossy conversion
    return static_cast<double>(ratingSum) / numOfRatings;
 
}

//Determining the max rating
void Restaurant::setMaxRating(int newRating) {
    if (newRating > maxRating) {
        maxRating = newRating;
    }
    
}






















