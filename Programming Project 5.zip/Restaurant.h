/************************************************************************************************************

Student Name:  Blake Fowler
Course:  C++ Programming (COP2334)
Date:  4/12/2024

This is Programming Project 5. In this class all the variables and constructors
are initialized to be used in Restaurant.cpp
************************************************************************************************************/


//Setting up the header file
#ifndef RESTAURANT_H
#define RESTAURANT_H

#include <string>

using namespace std;


class Restaurant {
    
    private:
    //All of our private variables
    string name;
    int seatingCapacity;
    int ratingSum;
    int numOfRatings;
    int maxRating;
    
    
    public:
    
    //All our public mutators and setters
    Restaurant();
    Restaurant(string name, int seatingCapacity);

    
    
    
    string getName();
    int getSeatingCapacity();
    int getMaxRating();
    double getAverage();
    
    void setName(string name);
    void setSeatingCapacity(int seatingCapacity);
    void setMaxRating(int newRating);
    
    void addRating(int newRating);
};



#endif //Ending the header part 



