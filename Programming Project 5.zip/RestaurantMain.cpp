/************************************************************************************************************

Student Name:  Blake Fowler
Course:  C++ Programming (COP2334)
Date:  4/12/2024

This is Programming Project 5. In this project, three classes-- main.cpp, 
Restaurant.cpp, and Restaurant.h, all work together to construct a neat and
legibile program that creates a restaurant. The user enters as many ratings
as they want and the average rating of the restaurant is attained accordingly.
Afterwards default constructors are used to print out the name of the Restaurant
and its seating capacity. 
************************************************************************************************************/

//Setting everything up 
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <sstream>
using namespace std;

#include "Restaurant.h"  //Making sure to include our header file
#include <iostream>


int main() {
    
     Restaurant myRestaurant("Fowler Famous Chicken", 150); //Setting up a default restaurant
     
    //Prompts user for input and continues to do so until the user enters a negative number 
    cout << "Please enter ratings for the restaurant. When you're done, enter a negative number:" << endl;
    int rating;
    while (true) {
        cin >> rating;
        if (rating < 0) {
            break;
        }
         myRestaurant.addRating(rating); // Numbers are continuously added as the user enters them
         myRestaurant.setMaxRating(rating);
    }
    
    
    //Average rating has been calculated and is printed out with a precision of 2
    cout << myRestaurant.getName() << " has an average rating of " << fixed << setprecision(2) << myRestaurant.getAverage() << endl;
    cout << "It has a maximum rating of " << myRestaurant.getMaxRating() << endl;
    
    // Create a default restaurant object
    Restaurant defaultRestaurant;

    // Test setName and setSeatingCapacity functions
    defaultRestaurant.setName("Fowler Famous Chicken");
    defaultRestaurant.setSeatingCapacity(150);

    // Print out the name and seating capacity of the default restaurant object
    cout << "Name: " << defaultRestaurant.getName() << endl;
    cout << "Seating Capacity: " << defaultRestaurant.getSeatingCapacity() << endl;
    
    
    
    
    return 0; //End of program
}


















